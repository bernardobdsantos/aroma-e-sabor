import { useEffect, useState } from 'react'
import { Menu as MenuIcon, X, MessageCircle } from 'lucide-react'
import { whatsappLink } from '../lib/whatsapp.js'

const LINKS = [
  { label: 'Início', href: '#inicio' },
  { label: 'Cardápio', href: '#cardapio' },
  { label: 'Sobre', href: '#sobre' },
  { label: 'Avaliações', href: '#avaliacoes' },
  { label: 'Localização', href: '#localizacao' },
]

export default function Header() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
  }, [open])

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-cream-50/95 backdrop-blur shadow-[0_2px_16px_rgba(74,46,31,0.08)] py-2' : 'bg-transparent py-4'
      }`}
      style={{ paddingTop: scrolled ? undefined : 'max(env(safe-area-inset-top,0px),1rem)' }}
    >
      <div className="max-w-6xl mx-auto px-5 flex items-center justify-between">
        <a href="#inicio" className="flex items-center gap-2.5 group" onClick={() => setOpen(false)}>
          <span
            className={`font-display leading-[0.85] transition-all ${
              scrolled ? 'text-lg' : 'text-xl'
            } ${scrolled ? 'text-cocoa-600' : 'text-cocoa-700'}`}
          >
            <span className="block font-semibold tracking-tight">Aroma<span className="text-toast-600"> & </span>Sabor</span>
            <span className="block text-[0.62rem] font-body font-medium uppercase tracking-[0.16em] text-cocoa-500/80 mt-0.5">
              Restaurante & Lancheria
            </span>
          </span>
        </a>

        <nav className="hidden md:flex items-center gap-8">
          {LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-[0.92rem] font-medium text-cocoa-600 hover:text-toast-600 transition-colors"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href={whatsappLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2 bg-toast-600 hover:bg-toast-700 text-cream-50 font-semibold text-sm px-5 py-2.5 rounded-full transition-colors shadow-sm"
          >
            <MessageCircle size={16} />
            Pedir agora
          </a>
          <button
            className="md:hidden p-2 text-cocoa-600"
            aria-label={open ? 'Fechar menu' : 'Abrir menu'}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={26} /> : <MenuIcon size={26} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden absolute top-full inset-x-0 bg-cream-50 border-t border-cocoa-600/10 shadow-lg animate-riseIn">
          <nav className="flex flex-col px-5 py-4 gap-1">
            {LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="py-3 text-base font-medium text-cocoa-600 border-b border-cocoa-600/5 last:border-none"
              >
                {link.label}
              </a>
            ))}
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setOpen(false)}
              className="mt-3 inline-flex items-center justify-center gap-2 bg-toast-600 text-cream-50 font-semibold text-base px-5 py-3.5 rounded-full"
            >
              <MessageCircle size={18} />
              Pedir pelo WhatsApp
            </a>
          </nav>
        </div>
      )}
    </header>
  )
}
