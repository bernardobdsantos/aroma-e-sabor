import { ImageIcon } from 'lucide-react'

/**
 * Visual placeholder used wherever a real photo has not been supplied yet.
 * Clearly labeled so it is obvious what should be replaced before launch.
 */
export default function PlaceholderPhoto({ label, className = '', iconSize = 28 }) {
  return (
    <div
      className={`placeholder-photo flex flex-col items-center justify-center gap-2 text-cocoa-500/70 ${className}`}
      role="img"
      aria-label={`Espaço reservado para foto: ${label}`}
    >
      <ImageIcon size={iconSize} strokeWidth={1.5} />
      <span className="text-xs font-medium text-center px-3 leading-snug">{label}</span>
    </div>
  )
}
