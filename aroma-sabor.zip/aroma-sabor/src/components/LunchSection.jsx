import PlaceholderPhoto from './PlaceholderPhoto.jsx'

export default function LunchSection() {
  return (
    <section className="py-16 md:py-20">
      <div className="max-w-6xl mx-auto px-5 grid md:grid-cols-2 gap-10 items-center">
        <PlaceholderPhoto
          label="Foto — almoço caseiro servido à mesa"
          className="aspect-[4/3] rounded-2xl"
          iconSize={32}
        />
        <div>
          <h2 className="section-title reveal text-3xl md:text-4xl font-semibold text-cocoa-700">
            Almoço com gostinho de casa
          </h2>
          <p className="reveal mt-4 text-cocoa-500 leading-relaxed max-w-md">
            Uma refeição feita para matar a fome e deixar aquele gostinho de quero mais.
          </p>
          <a
            href="#cardapio"
            className="reveal inline-flex mt-7 items-center gap-2 bg-cocoa-600 hover:bg-cocoa-700 text-cream-50 font-semibold px-7 py-3.5 rounded-full transition-colors"
          >
            Ver opções
          </a>
        </div>
      </div>
    </section>
  )
}
