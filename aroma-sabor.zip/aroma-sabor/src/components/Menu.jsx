import { GlassWater } from 'lucide-react'
import PlaceholderPhoto from './PlaceholderPhoto.jsx'

const CATEGORIES = [
  { label: 'À La Carte', href: '#a-la-carte' },
  { label: 'Lanches', href: '#lanches' },
  { label: 'Xis', href: '#lanches' },
  { label: 'Hot Dog', href: '#lanches' },
  { label: 'Porções', href: '#porcoes' },
  { label: 'Picados', href: '#porcoes' },
  { label: 'Bebidas', href: '#bebidas' },
]

export default function Menu() {
  return (
    <section id="cardapio" className="py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-5">
        <div className="max-w-xl">
          <h2 className="section-title reveal text-3xl md:text-4xl font-semibold text-cocoa-700">
            Nosso cardápio
          </h2>
          <p className="reveal mt-3 text-cocoa-500">
            Do almoço ao lanche, tem sabor para todos os momentos.
          </p>
        </div>

        <div className="mt-8 -mx-5 px-5 flex gap-2.5 overflow-x-auto pb-2 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden">
          {CATEGORIES.map((cat) => (
            <a
              key={cat.label}
              href={cat.href}
              className="shrink-0 px-5 py-2.5 rounded-full border border-cocoa-600/15 text-sm font-semibold text-cocoa-600 hover:bg-cocoa-600 hover:text-cream-50 hover:border-cocoa-600 transition-colors"
            >
              {cat.label}
            </a>
          ))}
        </div>

        <p className="mt-8 reveal text-xs text-cocoa-500/80 bg-cream-100 border border-cocoa-600/10 rounded-xl px-4 py-3 max-w-xl">
          Os itens do cardápio abaixo ainda serão preenchidos com fotos, nomes, descrições e
          preços reais. Por enquanto, as seções mostram a estrutura e as categorias já
          identificadas no estabelecimento.
        </p>

        <div id="bebidas" className="mt-14 scroll-mt-24">
          <div className="flex items-center gap-2.5 mb-6">
            <GlassWater size={20} className="text-herb-600" />
            <h3 className="font-display text-2xl font-semibold text-cocoa-700">Bebidas</h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div
                key={i}
                className="reveal rounded-2xl border border-cocoa-600/10 bg-cream-50 overflow-hidden"
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                <PlaceholderPhoto label="Bebida (em breve)" className="aspect-square" iconSize={20} />
                <div className="p-3">
                  <p className="text-sm font-semibold text-cocoa-600">Bebida em breve</p>
                  <p className="text-xs text-cocoa-500 mt-0.5">Preço a confirmar</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
