import { MessageCircle } from 'lucide-react'
import { whatsappLink, WHATSAPP_DISPLAY } from '../lib/whatsapp.js'

export default function WhatsAppCTA() {
  return (
    <section className="py-16 md:py-20 bg-herb-600 text-cream-50">
      <div className="max-w-3xl mx-auto px-5 text-center">
        <h2 className="section-title reveal text-3xl md:text-4xl font-semibold">Quer pedir?</h2>
        <p className="reveal mt-3 text-cream-50/90">
          Faça seu pedido de forma rápida pelo WhatsApp.
        </p>

        <a
          href={whatsappLink()}
          target="_blank"
          rel="noopener noreferrer"
          className="reveal mt-8 inline-flex items-center gap-3 bg-cream-50 text-herb-600 font-bold text-lg px-9 py-5 rounded-full hover:bg-cream-100 transition-colors shadow-lg"
        >
          <MessageCircle size={22} />
          Pedir pelo WhatsApp
        </a>

        <p className="reveal mt-5 text-sm text-cream-50/75">{WHATSAPP_DISPLAY}</p>
      </div>
    </section>
  )
}
