import { CookingPot, Heart, Sandwich, Wallet } from 'lucide-react'

const ITEMS = [
  {
    icon: CookingPot,
    title: 'Comida caseira',
    text: 'Comida preparada com sabor e carinho.',
  },
  {
    icon: Heart,
    title: 'Ambiente familiar',
    text: 'Um lugar agradável para aproveitar sua refeição.',
  },
  {
    icon: Sandwich,
    title: 'Lanches',
    text: 'Opções de lancheria para diferentes momentos.',
  },
  {
    icon: Wallet,
    title: 'Preço acessível',
    text: 'Faixa média informada de R$ 20–40 por pessoa.',
  },
]

export default function Highlights() {
  return (
    <section className="py-16 md:py-20 bg-cream-100/60">
      <div className="max-w-6xl mx-auto px-5">
        <h2 className="section-title reveal text-3xl md:text-4xl font-semibold text-cocoa-700 text-center max-w-xl mx-auto">
          Por que Aroma & Sabor?
        </h2>

        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {ITEMS.map(({ icon: Icon, title, text }, i) => (
            <div
              key={title}
              className="reveal bg-cream-50 rounded-2xl p-6 border border-cocoa-600/8 hover:border-toast-500/40 hover:-translate-y-1 transition-all duration-300"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <div className="w-12 h-12 rounded-xl bg-toast-600/10 flex items-center justify-center text-toast-600 mb-4">
                <Icon size={24} strokeWidth={1.75} />
              </div>
              <h3 className="font-display text-lg font-semibold text-cocoa-700">{title}</h3>
              <p className="mt-1.5 text-sm text-cocoa-500 leading-relaxed">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
