import { whatsappLink } from '../lib/whatsapp.js'
import PlaceholderPhoto from './PlaceholderPhoto.jsx'

const CATEGORIAS = ['Xis', 'Hot Dog', 'Lanches']

export default function Lanches() {
  return (
    <section id="lanches" className="py-16 md:py-20 scroll-mt-20">
      <div className="max-w-6xl mx-auto px-5">
        <div className="max-w-xl">
          <h2 className="section-title reveal text-3xl md:text-4xl font-semibold text-cocoa-700">
            Deu fome?
          </h2>
          <p className="reveal mt-3 text-cocoa-500">
            Xis, hot dog e lanches para matar aquela vontade a qualquer hora do dia.
          </p>
        </div>

        <div className="mt-10 grid sm:grid-cols-3 gap-6">
          {CATEGORIAS.map((cat, i) => (
            <div
              key={cat}
              className="reveal rounded-2xl border border-cocoa-600/10 bg-cream-50 overflow-hidden hover:shadow-[0_16px_36px_rgba(74,46,31,0.12)] transition-shadow"
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <PlaceholderPhoto label={`Foto — categoria ${cat}`} className="aspect-[4/3]" iconSize={26} />
              <div className="p-5">
                <p className="text-[0.7rem] font-semibold uppercase tracking-wide text-toast-600">
                  Categoria
                </p>
                <h3 className="font-display text-xl font-semibold text-cocoa-700 mt-1">{cat}</h3>
                <p className="text-sm text-cocoa-500 mt-2">
                  Itens, ingredientes e preços serão adicionados em breve.
                </p>
                <a
                  href={whatsappLink(`Olá! Gostaria de saber mais sobre as opções de ${cat} do Aroma & Sabor.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex mt-4 items-center gap-2 text-sm font-semibold text-cocoa-600 hover:text-toast-600"
                >
                  Pedir →
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
