import { Instagram, Phone, MapPin } from 'lucide-react'

const LINKS = [
  { label: 'Início', href: '#inicio' },
  { label: 'Cardápio', href: '#cardapio' },
  { label: 'Sobre', href: '#sobre' },
  { label: 'Avaliações', href: '#avaliacoes' },
  { label: 'Instagram', href: 'https://www.instagram.com/aromaesaborsantiago/' },
  { label: 'Localização', href: '#localizacao' },
]

export default function Footer() {
  return (
    <footer className="bg-cocoa-900 text-cream-100/80 pt-14 pb-8">
      <div className="max-w-6xl mx-auto px-5">
        <div className="grid sm:grid-cols-3 gap-10">
          <div>
            <p className="font-display text-xl font-semibold text-cream-50">Aroma & Sabor</p>
            <p className="text-sm mt-1">Restaurante e Lancheria</p>
            <p className="mt-4 text-sm italic text-cream-100/70 max-w-[220px]">
              "Comida caseira com sabor e carinho."
            </p>
          </div>

          <div>
            <p className="text-xs uppercase tracking-wide font-semibold text-cream-100/50 mb-3">
              Navegação
            </p>
            <ul className="space-y-2 text-sm">
              {LINKS.map((l) => (
                <li key={l.label}>
                  <a href={l.href} className="hover:text-toast-400 transition-colors">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-xs uppercase tracking-wide font-semibold text-cream-100/50 mb-3">
              Contato
            </p>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <Phone size={15} className="mt-0.5 shrink-0" />
                <a href="tel:+5555999207211">(55) 99920-7211</a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin size={15} className="mt-0.5 shrink-0" />
                <span>R. 7 de Setembro, 525 — Centro, Santiago/RS</span>
              </li>
              <li className="flex items-start gap-2">
                <Instagram size={15} className="mt-0.5 shrink-0" />
                <a
                  href="https://www.instagram.com/aromaesaborsantiago/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  @aromaesaborsantiago
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-cream-50/10 text-xs text-cream-100/50 text-center">
          © 2026 Aroma & Sabor. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  )
}
