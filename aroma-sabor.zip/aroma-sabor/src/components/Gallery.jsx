import PlaceholderPhoto from './PlaceholderPhoto.jsx'

const ITEMS = [
  'Comida',
  'Lanches',
  'Ambiente',
  'Pratos',
  'Bebidas',
  'Comida',
]

export default function Gallery() {
  return (
    <section className="py-16 md:py-20 bg-cream-100/60">
      <div className="max-w-6xl mx-auto px-5">
        <h2 className="section-title reveal text-3xl md:text-4xl font-semibold text-cocoa-700 text-center">
          Um pouco do Aroma & Sabor
        </h2>

        <div className="mt-10 grid grid-cols-2 sm:grid-cols-3 gap-4">
          {ITEMS.map((label, i) => (
            <PlaceholderPhoto
              key={i}
              label={label}
              iconSize={22}
              className={`reveal rounded-2xl ${i === 0 ? 'col-span-2 aspect-[16/10] sm:col-span-1 sm:aspect-square' : 'aspect-square'}`}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
