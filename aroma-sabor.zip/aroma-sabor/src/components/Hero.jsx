import { Star, MessageCircle, UtensilsCrossed } from 'lucide-react'
import { whatsappLink } from '../lib/whatsapp.js'
import PlaceholderPhoto from './PlaceholderPhoto.jsx'

export default function Hero() {
  return (
    <section id="inicio" className="relative pt-32 pb-16 md:pt-40 md:pb-24 overflow-hidden">
      <div className="max-w-6xl mx-auto px-5 grid md:grid-cols-[1.1fr_0.9fr] gap-10 md:gap-14 items-center">
        <div>
          <p className="inline-flex items-center gap-2 text-brick-500 font-semibold text-sm mb-5">
            <UtensilsCrossed size={16} />
            Santiago — RS
          </p>
          <h1 className="section-title text-[2.5rem] leading-[1.02] sm:text-5xl md:text-6xl font-semibold text-cocoa-700">
            Sabor de casa.
            <br />
            Carinho em cada refeição.
          </h1>
          <p className="mt-6 text-lg text-cocoa-500 font-medium max-w-md">
            Comida caseira, lanches e petiscos em Santiago.
          </p>
          <p className="mt-3 text-cocoa-500/90 max-w-md leading-relaxed">
            Do almoço ao lanche da noite, encontre sabor, variedade e aquele atendimento que faz
            você se sentir em casa.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <a
              href="#cardapio"
              className="inline-flex items-center justify-center gap-2 bg-cocoa-600 hover:bg-cocoa-700 text-cream-50 font-semibold px-7 py-4 rounded-full transition-colors text-[0.95rem]"
            >
              Ver cardápio
            </a>
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-toast-600 hover:bg-toast-700 text-cream-50 font-semibold px-7 py-4 rounded-full transition-colors text-[0.95rem]"
            >
              <MessageCircle size={18} />
              Pedir pelo WhatsApp
            </a>
          </div>

          <div className="mt-9 flex items-center gap-3">
            <div className="flex text-toast-600">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} size={18} fill="currentColor" strokeWidth={0} />
              ))}
            </div>
            <p className="text-sm text-cocoa-600">
              <span className="font-bold">4,6</span> no Google ·{' '}
              <span className="text-cocoa-500">34 avaliações</span>
            </p>
          </div>
        </div>

        <div className="relative">
          <PlaceholderPhoto
            label="Foto principal — prato caseiro servido, ambiente acolhedor"
            className="aspect-[4/5] md:aspect-[3/4] rounded-[2rem] shadow-[0_24px_60px_rgba(74,46,31,0.18)]"
            iconSize={36}
          />
          <div className="absolute -bottom-6 -left-6 hidden sm:block bg-cream-50 rounded-2xl shadow-lg px-5 py-4 border border-cocoa-600/10">
            <p className="font-display text-2xl text-cocoa-700 leading-none">1,4 mil+</p>
            <p className="text-xs text-cocoa-500 mt-1">seguidores no Instagram</p>
          </div>
        </div>
      </div>
    </section>
  )
}
