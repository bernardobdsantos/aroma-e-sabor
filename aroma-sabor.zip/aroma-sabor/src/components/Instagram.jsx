import { Instagram, ExternalLink } from 'lucide-react'
import PlaceholderPhoto from './PlaceholderPhoto.jsx'

const INSTAGRAM_URL = 'https://www.instagram.com/aromaesaborsantiago/'

export default function InstagramSection() {
  return (
    <section className="py-16 md:py-20">
      <div className="max-w-6xl mx-auto px-5">
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div>
            <h2 className="section-title reveal text-3xl md:text-4xl font-semibold text-cocoa-700">
              Siga o Aroma & Sabor
            </h2>
            <p className="reveal mt-3 text-cocoa-500 max-w-md">
              Confira nossas opções, novidades e momentos do restaurante no Instagram.
            </p>
            <p className="reveal mt-2 text-sm text-cocoa-600 font-semibold">
              @aromaesaborsantiago · Mais de 1,4 mil seguidores
            </p>
          </div>
          <a
            href={INSTAGRAM_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="reveal inline-flex items-center gap-2 bg-brick-500 hover:bg-brick-600 text-cream-50 font-semibold px-6 py-3.5 rounded-full transition-colors shrink-0"
          >
            <Instagram size={18} />
            Ver no Instagram
          </a>
        </div>

        <div className="mt-9 grid grid-cols-2 sm:grid-cols-4 gap-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <a
              key={i}
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="reveal group relative aspect-square rounded-xl overflow-hidden"
              style={{ transitionDelay: `${i * 40}ms` }}
            >
              <PlaceholderPhoto label="Publicação do Instagram" className="w-full h-full" iconSize={18} />
              <span className="absolute inset-0 bg-cocoa-700/0 group-hover:bg-cocoa-700/30 transition-colors flex items-center justify-center">
                <ExternalLink
                  size={20}
                  className="text-cream-50 opacity-0 group-hover:opacity-100 transition-opacity"
                />
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  )
}
