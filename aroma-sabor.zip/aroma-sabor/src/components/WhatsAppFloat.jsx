import { MessageCircle } from 'lucide-react'
import { whatsappLink } from '../lib/whatsapp.js'

export default function WhatsAppFloat() {
  return (
    <a
      href={whatsappLink()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Pedir pelo WhatsApp"
      className="fixed z-40 bottom-5 right-5 w-14 h-14 rounded-full bg-herb-600 hover:bg-herb-500 text-cream-50 flex items-center justify-center shadow-[0_10px_30px_rgba(74,46,31,0.3)] transition-transform hover:scale-105"
      style={{ marginBottom: 'env(safe-area-inset-bottom, 0px)' }}
    >
      <MessageCircle size={26} />
    </a>
  )
}
