import PlaceholderPhoto from './PlaceholderPhoto.jsx'

export default function About() {
  return (
    <section id="sobre" className="py-16 md:py-24 scroll-mt-20">
      <div className="max-w-6xl mx-auto px-5 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h2 className="section-title reveal text-3xl md:text-4xl font-semibold text-cocoa-700">
            Um lugar para se sentir em casa
          </h2>
          <p className="reveal mt-5 text-cocoa-500 leading-relaxed max-w-md">
            O Aroma & Sabor é uma lancheria e restaurante em Santiago/RS, com uma proposta
            baseada em comida caseira, sabor e carinho.
          </p>
          <p className="reveal mt-4 text-cocoa-500 leading-relaxed max-w-md">
            Do almoço aos lanches, o estabelecimento oferece opções para diferentes momentos do
            dia.
          </p>

          <blockquote className="reveal mt-7 border-l-4 border-toast-500 pl-5 font-display text-xl text-cocoa-700 italic">
            "Comida caseira com sabor e carinho."
          </blockquote>
        </div>

        <PlaceholderPhoto
          label="Foto — ambiente interno do restaurante"
          className="aspect-[4/3] rounded-2xl"
          iconSize={32}
        />
      </div>
    </section>
  )
}
