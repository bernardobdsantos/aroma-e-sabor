import { Clock, TrendingUp, CalendarX } from 'lucide-react'

export default function OpeningHours() {
  return (
    <section className="py-16 md:py-20">
      <div className="max-w-3xl mx-auto px-5">
        <div className="reveal bg-cocoa-600 text-cream-50 rounded-3xl p-8 md:p-10">
          <div className="flex items-center gap-2.5 mb-6">
            <Clock size={22} className="text-toast-400" />
            <h2 className="font-display text-2xl md:text-3xl font-semibold">Funcionamento</h2>
          </div>

          <div className="grid sm:grid-cols-2 gap-5">
            <div className="bg-cream-50/10 rounded-2xl p-5">
              <p className="text-xs uppercase tracking-wide text-cream-100/70 font-semibold">
                Segunda a sábado
              </p>
              <p className="font-display text-2xl mt-1">08:00 — 23:00</p>
            </div>
            <div className="bg-cream-50/10 rounded-2xl p-5 flex flex-col justify-center">
              <div className="flex items-center gap-2 text-cream-100/70">
                <CalendarX size={16} />
                <p className="text-xs uppercase tracking-wide font-semibold">Domingo</p>
              </div>
              <p className="mt-1 text-cream-50/95">Horário não informado</p>
            </div>
          </div>

          <div className="mt-5 flex items-center gap-2 text-sm text-cream-100/85">
            <TrendingUp size={16} className="text-toast-400 shrink-0" />
            <p>Horário de maior movimento: 21:00</p>
          </div>
          <p className="mt-2 text-xs text-cream-100/60">
            Sem fila de espera, conforme informação disponível.
          </p>
        </div>
      </div>
    </section>
  )
}
