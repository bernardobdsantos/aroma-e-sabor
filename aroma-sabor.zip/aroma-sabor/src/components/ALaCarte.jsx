import { Quote } from 'lucide-react'
import PlaceholderPhoto from './PlaceholderPhoto.jsx'

export default function ALaCarte() {
  return (
    <section id="a-la-carte" className="py-16 md:py-20 bg-cocoa-700 text-cream-50 scroll-mt-20">
      <div className="max-w-6xl mx-auto px-5 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h2 className="section-title reveal text-3xl md:text-4xl font-semibold">
            Comida de verdade
          </h2>
          <p className="reveal mt-4 text-cream-100/85 leading-relaxed max-w-md">
            Pratos à la carte feitos com o mesmo cuidado de uma cozinha de casa — para quem quer
            sentar, pedir e comer bem.
          </p>

          <div className="reveal mt-8 bg-cream-50/10 border border-cream-50/15 rounded-2xl p-5 max-w-md">
            <Quote size={22} className="text-toast-400 mb-2" />
            <p className="italic text-cream-50/95 leading-relaxed">
              "Pedi um parmegiana pra 2 pessoas, não aguentamos comer tudo, bem servido."
            </p>
            <p className="mt-3 text-sm text-cream-100/70">
              — Comentário de cliente no Google · Edinelson Corrêa
            </p>
            <p className="mt-3 text-xs text-cream-100/60">
              Preço, porção e acompanhamentos a confirmar diretamente com o estabelecimento.
            </p>
          </div>
        </div>

        <PlaceholderPhoto
          label="Foto do prato à la carte — ex: parmegiana"
          className="aspect-[4/3] rounded-2xl"
          iconSize={32}
        />
      </div>
    </section>
  )
}
