import { MessageCircle, Navigation } from 'lucide-react'
import { whatsappLink } from '../lib/whatsapp.js'

export default function FinalCTA() {
  return (
    <section className="py-16 md:py-24">
      <div className="max-w-4xl mx-auto px-5">
        <div className="reveal bg-gradient-to-br from-toast-600 to-brick-500 text-cream-50 rounded-[2rem] px-8 py-14 md:py-16 text-center">
          <h2 className="section-title text-3xl md:text-4xl font-semibold">Está com fome?</h2>
          <p className="mt-3 text-cream-50/90 max-w-md mx-auto">
            Venha conhecer o Aroma & Sabor ou faça seu pedido pelo WhatsApp.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-cream-50 text-brick-600 font-bold px-7 py-4 rounded-full hover:bg-cream-100 transition-colors"
            >
              <MessageCircle size={18} />
              Pedir agora
            </a>
            <a
              href="#localizacao"
              className="inline-flex items-center justify-center gap-2 border-2 border-cream-50 text-cream-50 font-bold px-7 py-4 rounded-full hover:bg-cream-50/10 transition-colors"
            >
              <Navigation size={18} />
              Como chegar
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
