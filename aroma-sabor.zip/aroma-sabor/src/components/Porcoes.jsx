import PlaceholderPhoto from './PlaceholderPhoto.jsx'

const ITENS = ['Porções', 'Petiscos', 'Picados']

export default function Porcoes() {
  return (
    <section id="porcoes" className="py-16 md:py-20 bg-cream-100/60 scroll-mt-20">
      <div className="max-w-6xl mx-auto px-5 grid md:grid-cols-[0.9fr_1.1fr] gap-10 items-center">
        <div className="order-2 md:order-1">
          <PlaceholderPhoto
            label="Foto — mesa com porções e petiscos para compartilhar"
            className="aspect-[4/3] rounded-2xl"
            iconSize={32}
          />
        </div>

        <div className="order-1 md:order-2">
          <h2 className="section-title reveal text-3xl md:text-4xl font-semibold text-cocoa-700">
            Para compartilhar
          </h2>
          <p className="reveal mt-3 text-cocoa-500 max-w-md">
            Porções, petiscos e picados para dividir na mesa, do jeito que a boa companhia pede.
          </p>

          <div className="mt-7 flex flex-wrap gap-3">
            {ITENS.map((item) => (
              <span
                key={item}
                className="reveal px-4 py-2 rounded-full bg-cream-50 border border-cocoa-600/12 text-sm font-semibold text-cocoa-600"
              >
                {item}
              </span>
            ))}
          </div>

          <p className="reveal mt-6 text-xs text-cocoa-500/80 bg-cream-50 border border-cocoa-600/10 rounded-xl px-4 py-3 max-w-md">
            Nomes específicos de porções e petiscos ainda não foram informados — em breve essa
            seção trará os itens reais do cardápio.
          </p>
        </div>
      </div>
    </section>
  )
}
