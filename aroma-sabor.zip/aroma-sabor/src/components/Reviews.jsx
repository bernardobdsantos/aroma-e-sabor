import { Star } from 'lucide-react'

const REVIEWS = [
  {
    name: 'Luis Tamioso',
    text: 'Ótimo atendimento, ambiente familiar, ótimos preços e produtos.',
  },
  {
    name: 'Edinelson Corrêa',
    text: 'Pedi um parmegiana pra 2 pessoas, não aguentamos comer tudo, bem servido.',
  },
  {
    name: 'Ana Paula Fernandes',
    text: 'Adorei... ambiente agradável... comida excelente... nota 1000...',
  },
]

function Stars() {
  return (
    <div className="flex text-toast-600 mb-3">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} size={15} fill="currentColor" strokeWidth={0} />
      ))}
    </div>
  )
}

export default function Reviews() {
  return (
    <section id="avaliacoes" className="py-16 md:py-24 bg-cream-100/60 scroll-mt-20">
      <div className="max-w-6xl mx-auto px-5">
        <div className="text-center max-w-xl mx-auto">
          <h2 className="section-title reveal text-3xl md:text-4xl font-semibold text-cocoa-700">
            O que nossos clientes dizem
          </h2>
          <div className="reveal mt-4 flex items-center justify-center gap-2">
            <div className="flex text-toast-600">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} size={18} fill="currentColor" strokeWidth={0} />
              ))}
            </div>
            <p className="text-cocoa-600 font-semibold">4,6 / 5</p>
          </div>
          <p className="reveal text-sm text-cocoa-500 mt-1">34 avaliações no Google</p>
        </div>

        <div className="mt-12 grid sm:grid-cols-3 gap-5">
          {REVIEWS.map((r, i) => (
            <div
              key={r.name}
              className="reveal bg-cream-50 rounded-2xl p-6 border border-cocoa-600/8"
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <Stars />
              <p className="text-cocoa-600 leading-relaxed">"{r.text}"</p>
              <p className="mt-4 text-sm font-semibold text-cocoa-700">{r.name}</p>
              <p className="text-xs text-cocoa-500">Avaliação no Google</p>
            </div>
          ))}
        </div>

        <div className="mt-10 text-center">
          <a
            href="https://www.google.com/search?q=Aroma+e+Sabor+Santiago+RS"
            target="_blank"
            rel="noopener noreferrer"
            className="reveal inline-flex items-center gap-2 border-2 border-cocoa-600 text-cocoa-600 font-semibold px-7 py-3.5 rounded-full hover:bg-cocoa-600 hover:text-cream-50 transition-colors"
          >
            Ver mais avaliações
          </a>
        </div>
      </div>
    </section>
  )
}
