import { MapPin, Phone, Navigation } from 'lucide-react'

const ADDRESS = 'R. 7 de Setembro, 525 - Centro, Santiago - RS, 97707-000'
const MAPS_DIRECTIONS = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(ADDRESS)}`
const MAPS_EMBED = `https://www.google.com/maps?q=${encodeURIComponent(ADDRESS)}&output=embed`

export default function Location() {
  return (
    <section id="localizacao" className="py-16 md:py-24 bg-cream-100/60 scroll-mt-20">
      <div className="max-w-6xl mx-auto px-5 grid md:grid-cols-[0.85fr_1.15fr] gap-10">
        <div>
          <h2 className="section-title reveal text-3xl md:text-4xl font-semibold text-cocoa-700">
            Venha nos visitar
          </h2>

          <div className="reveal mt-6 flex items-start gap-3">
            <MapPin size={20} className="text-toast-600 mt-0.5 shrink-0" />
            <div>
              <p className="font-semibold text-cocoa-700">Aroma & Sabor</p>
              <p className="text-sm text-cocoa-500">Restaurante e Lancheria</p>
              <a
                href={MAPS_DIRECTIONS}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-cocoa-600 underline decoration-cocoa-600/30 hover:decoration-cocoa-600 mt-1 inline-block"
              >
                R. 7 de Setembro, 525, Centro, Santiago - RS, 97707-000
              </a>
            </div>
          </div>

          <div className="reveal mt-4 flex items-center gap-3">
            <Phone size={20} className="text-toast-600 shrink-0" />
            <a href="tel:+5555999207211" className="text-sm text-cocoa-600 font-semibold">
              (55) 99920-7211
            </a>
          </div>

          <a
            href={MAPS_DIRECTIONS}
            target="_blank"
            rel="noopener noreferrer"
            className="reveal mt-8 inline-flex items-center gap-2 bg-cocoa-600 hover:bg-cocoa-700 text-cream-50 font-semibold px-7 py-3.5 rounded-full transition-colors"
          >
            <Navigation size={16} />
            Como chegar
          </a>
        </div>

        <div className="reveal rounded-2xl overflow-hidden border border-cocoa-600/10 min-h-[280px]">
          <iframe
            title="Mapa - Aroma & Sabor"
            src={MAPS_EMBED}
            width="100%"
            height="100%"
            style={{ border: 0, minHeight: 280 }}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </section>
  )
}
