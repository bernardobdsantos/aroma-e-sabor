import { useEffect } from 'react'
import Header from './components/Header.jsx'
import Hero from './components/Hero.jsx'
import Highlights from './components/Highlights.jsx'
import Menu from './components/Menu.jsx'
import ALaCarte from './components/ALaCarte.jsx'
import Lanches from './components/Lanches.jsx'
import Porcoes from './components/Porcoes.jsx'
import LunchSection from './components/LunchSection.jsx'
import WhatsAppCTA from './components/WhatsAppCTA.jsx'
import About from './components/About.jsx'
import Reviews from './components/Reviews.jsx'
import InstagramSection from './components/Instagram.jsx'
import Gallery from './components/Gallery.jsx'
import OpeningHours from './components/OpeningHours.jsx'
import Location from './components/Location.jsx'
import FinalCTA from './components/FinalCTA.jsx'
import Footer from './components/Footer.jsx'
import WhatsAppFloat from './components/WhatsAppFloat.jsx'

export default function App() {
  useEffect(() => {
    const els = document.querySelectorAll('.reveal')
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible')
            io.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.12 }
    )
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [])

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <Highlights />
        <Menu />
        <ALaCarte />
        <Lanches />
        <Porcoes />
        <LunchSection />
        <WhatsAppCTA />
        <About />
        <Reviews />
        <InstagramSection />
        <Gallery />
        <OpeningHours />
        <Location />
        <FinalCTA />
      </main>
      <Footer />
      <WhatsAppFloat />
    </div>
  )
}
