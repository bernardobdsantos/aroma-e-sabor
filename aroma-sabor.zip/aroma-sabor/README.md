# Aroma & Sabor — Site institucional

Site em React + Vite + Tailwind CSS + Lucide React para o Restaurante e Lancheria
Aroma & Sabor (Santiago - RS).

## Rodar localmente

```bash
npm install
npm run dev
```

Abra o endereço mostrado no terminal (normalmente http://localhost:5173).

## Gerar versão de produção

```bash
npm run build
npm run preview
```

## Publicar na Vercel (gratuito)

1. Crie um repositório no GitHub e envie esta pasta para ele.
2. Acesse https://vercel.com, clique em "Add New Project" e importe o repositório.
3. A Vercel detecta automaticamente que é um projeto Vite — não é preciso configurar nada.
4. Clique em "Deploy". Em poucos minutos o site estará no ar com um link público.

## O que ainda precisa ser preenchido

O conteúdo enviado não trouxe fotos, preços ou itens detalhados do cardápio, então o
site foi montado com placeholders claramente identificados nesses pontos. Antes de publicar
para o cliente final, substitua:

- **Fotos**: todos os quadros com o ícone de imagem e um texto explicando o que deve
  entrar ali (`src/components/PlaceholderPhoto.jsx` é o componente usado — basta trocar
  pelo componente `<img src="..." />` real quando as fotos chegarem).
- **Cardápio**: itens, ingredientes e preços de À La Carte, Lanches, Xis, Hot Dog,
  Porções, Picados e Bebidas (`src/components/Menu.jsx`, `ALaCarte.jsx`, `Lanches.jsx`,
  `Porcoes.jsx`).
- **Horário de domingo**: hoje está como "não informado" (`OpeningHours.jsx`).
- **Publicações do Instagram**: hoje são placeholders (`Instagram.jsx`); podem ser
  substituídas por um plugin de embed do Instagram ou por prints reais.

## Estrutura de componentes

```
src/
  App.jsx
  index.css
  lib/whatsapp.js        -> número e link de WhatsApp centralizados
  components/
    Header.jsx
    Hero.jsx
    Highlights.jsx
    Menu.jsx
    ALaCarte.jsx
    Lanches.jsx
    Porcoes.jsx
    LunchSection.jsx
    WhatsAppCTA.jsx
    About.jsx
    Reviews.jsx
    Instagram.jsx
    Gallery.jsx
    OpeningHours.jsx
    Location.jsx
    FinalCTA.jsx
    Footer.jsx
    WhatsAppFloat.jsx
    PlaceholderPhoto.jsx
```
