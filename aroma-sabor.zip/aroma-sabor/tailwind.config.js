/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        cream: {
          50: '#FFFDF8',
          100: '#FBF3E7',
          200: '#F5E7D3',
        },
        toast: {
          400: '#E0964F',
          500: '#D9762E',
          600: '#C25F22',
          700: '#A34D1C',
        },
        cocoa: {
          400: '#8A5A3B',
          500: '#5E3B26',
          600: '#4A2E1F',
          700: '#332015',
          900: '#221510',
        },
        herb: {
          500: '#5C7A52',
          600: '#4A6342',
        },
        brick: {
          500: '#A13D2B',
          600: '#8A3123',
        },
      },
      fontFamily: {
        display: ['"Fraunces"', 'serif'],
        body: ['"Karla"', 'sans-serif'],
      },
      backgroundImage: {
        grain: "radial-gradient(circle at 1px 1px, rgba(74,46,31,0.06) 1px, transparent 0)",
      },
      keyframes: {
        riseIn: {
          '0%': { opacity: '0', transform: 'translateY(18px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        riseIn: 'riseIn 0.7s ease-out both',
      },
    },
  },
  plugins: [],
}
